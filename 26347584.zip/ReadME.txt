*******************************
*** Reading the Code
*******************************

Every Script pretty much says what that specific game object does and interacts with others.
Transcend script is one that will not get flushed when changing Scenes. Used to pass around data.
GameController scripts are the ones in charge of the scene mostly. Any General feature/Component would be in there.

This was a rushed code and a learning curve for me, be warned!

*******************************
*** Compile
*******************************
If by compile you mean build then follow these steps:
1- Press "File"
2- Press "Build Settings..."
3- Press Player Settings and make sure that your resolution is set to **** 1600x800
3- Select Target Platform
4- Press "Build" or "Build & Run"
5- Select location and Name desired for executable.
6- Press Save.


*******************************
*** Run
*******************************
After Building, go to the location where you saved the executable and double click to run.
Make sure to have resolution at 1600x800

*******************************
*** Play
*******************************
Play the game using the AWSD keys for movement and your left click on mouse for shooting.
Do not hit any bullets as you will Lose upgrades.
At 0 upgrades, it is game over.
You have a maximum of 3 upgrades with each changing your weaponry.
You start with upgrade 1 installed.
After defeating a wave of fighters there will be bonus points and an upgrade available in the middle of the map.
There is 2 modes:
	Normal: Normal Gameplay.

The Game ends when you lose all your upgrades or you defeat the Big Giant Boss.

